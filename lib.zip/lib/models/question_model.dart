class Question {
  final String? id; // L'ID peut être null au départ, il sera défini après l'enregistrement
  final String numero;
  final String question_text;
  final String? commentaire;
  final String type;

  Question({
    this.id, // ID est optionnel
    required this.numero,
    required this.question_text,
    this.commentaire,
    required this.type,
  });

 // Méthode pour créer une nouvelle instance avec une question mise à jour
  Question copyWith({String? newQuestion, String? newcommentaire}) {
    return Question(
      id: this.id,
      numero: this.numero,
      question_text: newQuestion ?? this.question_text,
      commentaire: newcommentaire ?? this.commentaire,
      type: this.type,
    );
  }

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      id: json['id'], // L'ID sera renvoyé par l'API après l'enregistrement
      numero: json['numero'] ?? '',
      question_text: json['question_text'] ?? '',
      commentaire: json['commentaire'],
      type: json['type'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id, // L'ID peut être null si la question n'a pas encore été enregistrée
      'numero': numero,
      'question_text': question_text,
      'commentaire': commentaire,
      'type': type,
    };
  }
}
