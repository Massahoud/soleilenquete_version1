class Response {
  final String ?id; // ID unique de la réponse
  final String question_id; // ID de la question associée
  final String reponse_text; // Texte de la réponse

  Response({
    this.id,
    required this.question_id,
    required this.reponse_text,
  });
 
  // Méthode pour créer une nouvelle instance avec une réponse mise à jour
  Response copyWith({String? newResponseText}) {
    return Response(
      id: this.id,
      question_id: this.question_id,
      reponse_text: newResponseText ?? this.reponse_text,
    );
  }

  // Convertir JSON en instance de Response
  factory Response.fromJson(Map<String, dynamic> json) {
    return Response(
      id: json['id'] ?? '',
      question_id: json['question_id'] ?? '',
      reponse_text: json['reponse_text'] ?? '',
    );
  }

  // Convertir une instance de Response en JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'question_id': question_id,
      'reponse_text': reponse_text,
    };
  }
}
