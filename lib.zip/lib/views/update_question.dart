import 'package:flutter/material.dart';
import '../models/question_model.dart';
import '../models/reponse_model.dart';
import '../services/question_service.dart';
import '../services/response_service.dart';
class UpdateQuestionPage extends StatefulWidget {
  final String questionId; // L'ID de la question à mettre à jour
 final List<String> responseIds; // Liste des IDs des réponses

  UpdateQuestionPage({required this.questionId, required this.responseIds});

  @override
  _UpdateQuestionPageState createState() => _UpdateQuestionPageState();
}

class _UpdateQuestionPageState extends State<UpdateQuestionPage> {
  final QuestionService questionService = QuestionService();
  final ResponseService responseService = ResponseService();

  final TextEditingController numeroController = TextEditingController();
  final TextEditingController questionController = TextEditingController();
  final TextEditingController instructionController = TextEditingController();
  String selectedType = 'text';
  List<TextEditingController> responseControllers = [TextEditingController()];

  @override
  void initState() {
    super.initState();
    _loadQuestionData();
  }

 Future<void> _loadQuestionData() async {
  try {
    // Utiliser l'ID de la question pour récupérer les données
    final question = await questionService.getQuestionById(widget.questionId);

    // Remplir les champs avec les données récupérées
    numeroController.text = question.numero ?? ''; // Fournir une valeur par défaut si null
    questionController.text = question.question_text ?? ''; // Fournir une valeur par défaut si null
    instructionController.text = question.commentaire ?? ''; // Fournir une valeur par défaut si null
    selectedType = question.type ?? 'text'; // Fournir une valeur par défaut pour le type

    // Charger les réponses associées
    final responses = await responseService.getResponsesByQuestionId(widget.questionId);
    setState(() {
      responseControllers = responses
          .map((response) => TextEditingController(text: response.reponse_text ?? ''))
          .toList();
    });
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Erreur de chargement de la question: $e')),
    );
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Mettre à jour la Question')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Champ pour numéro de la question
              TextField(
                controller: numeroController,
                decoration: InputDecoration(labelText: 'Numéro de la Question'),
              ),
              // Champ pour texte de la question
              TextField(
                controller: questionController,
                decoration: InputDecoration(labelText: 'Texte de la Question'),
              ),
              // Champ pour l'instruction (non requis)
              TextField(
                controller: instructionController,
                decoration: InputDecoration(labelText: 'Instruction (optionnel)'),
              ),
              SizedBox(height: 20),
              // Champ pour le type (choix ou autre)
              DropdownButton<String>(
                value: selectedType,
                onChanged: (String? newValue) {
                  setState(() {
                    selectedType = newValue!;
                  });
                },
                items: <String>['text', 'reponseunique', 'reponsemultiples', 'photos']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              // Titre des réponses
              Text('Réponses', style: TextStyle(fontSize: 18)),

              // Liste dynamique des réponses
              ...responseControllers.asMap().entries.map((entry) {
                final index = entry.key;
                final controller = entry.value;
                return Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: controller,
                        decoration: InputDecoration(labelText: 'Réponse ${index + 1}'),
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _removeResponseField(index),
                    ),
                  ],
                );
              }).toList(),
              SizedBox(height: 10),
              // Bouton pour ajouter une réponse
              TextButton.icon(
                onPressed: _addResponseField,
                icon: Icon(Icons.add),
                label: Text('Ajouter une réponse'),
              ),
              SizedBox(height: 20),
              // Bouton pour mettre à jour la question et les réponses
              ElevatedButton(
                onPressed: _updateQuestion,
                child: Text('Mettre à jour la Question'),
              ),
            ],
          ),
        ),
      ),
    );
  }
Future<void> _updateQuestion() async {
  try {
    // Créer l'objet question mis à jour
    final updatedQuestion = Question(
      id: widget.questionId, // Utiliser l'ID pour identifier la question
      numero: numeroController.text,
      question_text: questionController.text,
      type: selectedType,
      commentaire: instructionController.text,
    );

    // Appeler le service pour mettre à jour la question dans la base de données
    await questionService.updateQuestion(widget.questionId, updatedQuestion);

    // Mettre à jour ou ajouter les réponses associées
    for (int i = 0; i < responseControllers.length; i++) {
      final responseText = responseControllers[i].text.trim();

      // Vérifier si la réponse est non vide
      if (responseText.isNotEmpty) {
        // Si l'ID de la réponse existe dans responseIds, mettre à jour la réponse correspondante
        String? responseId = widget.responseIds.length > i ? widget.responseIds[i] : null;

        final response = Response(
          id: responseId, // Utiliser l'ID si disponible
          question_id: widget.questionId,
          reponse_text: responseText,
        );

        // Si l'ID existe, mettre à jour la réponse, sinon créer une nouvelle réponse
        if (responseId != null) {
          await responseService.updateResponse(responseId, response); // Mise à jour de la réponse existante
        } else {
          await responseService.createResponse(response); // Créer une nouvelle réponse si l'ID est null
        }
      }
    }

    // Afficher un message de succès
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Question et réponses mises à jour avec succès')),
    );

    // Retourner à la page précédente
    Navigator.pop(context);
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Erreur: $e')),
    );
  }
}


  // Ajout de champ de réponse
  void _addResponseField() {
    setState(() {
      responseControllers.add(TextEditingController());
    });
  }

  // Suppression de champ de réponse
  void _removeResponseField(int index) {
    setState(() {
      responseControllers.removeAt(index);
    });
  }
}
