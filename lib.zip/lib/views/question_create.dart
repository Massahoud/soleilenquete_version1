import 'package:flutter/material.dart';
import '../services/question_service.dart';
import '../services/response_service.dart';
import '../models/question_model.dart';
import '../models/reponse_model.dart';

class CreateQuestionPage extends StatefulWidget {
  @override
  _CreateQuestionPageState createState() => _CreateQuestionPageState();
}

class _CreateQuestionPageState extends State<CreateQuestionPage> {
  final QuestionService questionService = QuestionService();
  final ResponseService responseService = ResponseService();

  final TextEditingController numeroController = TextEditingController();
  final TextEditingController questionController = TextEditingController();
  final TextEditingController instructionController = TextEditingController(); // Champ pour l'instruction
  String selectedType = 'choix'; // Valeur par défaut pour le type
  List<TextEditingController> responseControllers = [TextEditingController()];

  void _addResponseField() {
    setState(() {
      responseControllers.add(TextEditingController());
    });
  }

  void _removeResponseField(int index) {
    setState(() {
      responseControllers.removeAt(index);
    });
  }

  Future<void> _createQuestion() async {
    try {
      // Créer la question avec les champs de texte, y compris l'instruction et le type
      final question = Question(
        numero: numeroController.text,
        question_text: questionController.text,
        type: selectedType, // Utilisation du type sélectionné
        commentaire: instructionController.text, // Utilisation de l'instruction
      );

      // Appeler le service pour créer la question dans la base de données
      final newQuestion = await questionService.createQuestion(question);

      // Vérifier explicitement si l'ID est non nul
      if (newQuestion.id != null && newQuestion.id!.isNotEmpty) {
        // Créer les réponses associées
        for (final controller in responseControllers) {
          if (controller.text.isNotEmpty) {
            final response = Response(
              question_id: newQuestion.id!,
              reponse_text: controller.text,
            );
            // Appeler le service pour créer chaque réponse
            await responseService.createResponse(response);
          }
        }

        // Afficher un message de succès
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Question et réponses créées avec succès')),
        );
        
        // Retourner à la page précédente
        Navigator.pop(context);
      } else {
        throw Exception('L\'ID de la question est manquant');
      }
    } catch (e) {
      // Afficher un message d'erreur en cas d'échec
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Créer une Question')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Champ pour numéro de la question
              TextField(
                controller: numeroController,
                decoration: InputDecoration(labelText: 'Numéro de la Question'),
              ),
              // Champ pour texte de la question
              TextField(
                controller: questionController,
                decoration: InputDecoration(labelText: 'Texte de la Question'),
              ),
              // Champ pour l'instruction (non requis)
              TextField(
                controller: instructionController,
                decoration: InputDecoration(labelText: 'Instruction (optionnel)'),
              ),
              SizedBox(height: 20),
              // Champ pour le type (choix ou autre)
              DropdownButton<String>(
                value: selectedType,
                onChanged: (String? newValue) {
                  setState(() {
                    selectedType = newValue!;
                  });
                },
                items: <String>['choix', 'texte', 'multichoix']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              // Titre des réponses
              Text('Réponses', style: TextStyle(fontSize: 18)),
              
              // Liste dynamique des réponses
              ...responseControllers.asMap().entries.map((entry) {
                final index = entry.key;
                final controller = entry.value;
                return Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: controller,
                        decoration:
                            InputDecoration(labelText: 'Réponse ${index + 1}'),
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _removeResponseField(index),
                    ),
                  ],
                );
              }).toList(),
              SizedBox(height: 10),
              // Bouton pour ajouter une réponse
              TextButton.icon(
                onPressed: _addResponseField,
                icon: Icon(Icons.add),
                label: Text('Ajouter une réponse'),
              ),
              SizedBox(height: 20),
              // Bouton pour créer la question et les réponses
              ElevatedButton(
                onPressed: _createQuestion,
                child: Text('Créer la Question'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
